import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-save-your-view',
  templateUrl: './save-your-view.component.html',
  styleUrls: ['./save-your-view.component.css']
})
export class SaveYourViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
